package net.minecraft.client.player;

import net.minecraft.client.renderer.state.MapRenderState;
import net.minecraft.client.renderer.state.level.FirstPersonHandsAndItemsRenderState;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.component.DataComponents;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.HumanoidArm;
import net.minecraft.world.entity.LivingEntity.SwingDescription;
import net.minecraft.world.item.CrossbowItem;
import net.minecraft.world.item.ItemDisplayContext;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.MapItem;
import net.minecraft.world.level.saveddata.maps.MapId;
import net.minecraft.world.level.saveddata.maps.MapItemSavedData;

public class FirstPersonHandsAndItems {
	private ItemStack mainHandItem = ItemStack.EMPTY;
	private ItemStack offHandItem = ItemStack.EMPTY;
	private float mainHandHeight;
	private float oMainHandHeight;
	private float offHandHeight;
	private float oOffHandHeight;

	public void tick(final LocalPlayer player) {
		this.oMainHandHeight = this.mainHandHeight;
		this.oOffHandHeight = this.offHandHeight;
		ItemStack nextMainHand = player.getMainHandItem();
		ItemStack nextOffHand = player.getOffhandItem();
		if (this.shouldInstantlyReplaceVisibleItem(this.mainHandItem, nextMainHand, player)) {
			this.mainHandItem = nextMainHand;
		}

		if (this.shouldInstantlyReplaceVisibleItem(this.offHandItem, nextOffHand, player)) {
			this.offHandItem = nextOffHand;
		}

		if (player.isHandsBusy()) {
			this.mainHandHeight = Mth.clamp(this.mainHandHeight - 0.4F, 0.0F, 1.0F);
			this.offHandHeight = Mth.clamp(this.offHandHeight - 0.4F, 0.0F, 1.0F);
		} else {
			float attackAnim = player.getItemSwapScale(1.0F);
			float mainHandTargetHeight = this.mainHandItem != nextMainHand ? 0.0F : attackAnim * attackAnim * attackAnim;
			float offHandTargetHeight = this.offHandItem != nextOffHand ? 0.0F : 1.0F;
			this.mainHandHeight = this.mainHandHeight + Mth.clamp(mainHandTargetHeight - this.mainHandHeight, -0.4F, 0.4F);
			this.offHandHeight = this.offHandHeight + Mth.clamp(offHandTargetHeight - this.offHandHeight, -0.4F, 0.4F);
		}

		if (this.mainHandHeight < 0.1F) {
			this.mainHandItem = nextMainHand;
		}

		if (this.offHandHeight < 0.1F) {
			this.offHandItem = nextOffHand;
		}
	}

	public void itemUsed(final InteractionHand hand) {
		if (hand == InteractionHand.MAIN_HAND) {
			this.mainHandHeight = 0.0F;
		} else {
			this.offHandHeight = 0.0F;
		}
	}

	public void extractRenderState(final LocalPlayer player, final float partialTicks, final FirstPersonHandsAndItemsRenderState state) {
		SwingDescription currentSwing = player.getCurrentSwing();
		state.attackHand = currentSwing == null ? InteractionHand.MAIN_HAND : currentSwing.hand();
		state.viewXRot = player.getViewXRot(partialTicks);
		state.viewYRot = player.getViewYRot(partialTicks);
		state.xBob = Mth.lerp(partialTicks, player.xBobO, player.xBob);
		state.yBob = Mth.lerp(partialTicks, player.yBobO, player.yBob);
		state.isScoping = player.isScoping();
		state.useItemRemainingTicks = player.getUseItemRemainingTicks();
		state.handRenderSelection = evaluateWhichHandsToRender(player);
		state.mainHandItem = this.mainHandItem;
		state.offHandItem = this.offHandItem;
		state.mainHandHeight = this.mainHandHeight;
		state.oldMainHandHeight = this.oMainHandHeight;
		state.offHandHeight = this.offHandHeight;
		state.oldOffHandHeight = this.oOffHandHeight;
		boolean isMainHandRight = player.getMainArm() == HumanoidArm.RIGHT;
		ItemDisplayContext mainHandDisplayContext = isMainHandRight ? ItemDisplayContext.FIRST_PERSON_RIGHT_HAND : ItemDisplayContext.FIRST_PERSON_LEFT_HAND;
		ItemDisplayContext offHandDisplayContext = isMainHandRight ? ItemDisplayContext.FIRST_PERSON_LEFT_HAND : ItemDisplayContext.FIRST_PERSON_RIGHT_HAND;
		state.mainHandRenderState.clear();
		state.offHandRenderState.clear();
		player.minecraft
			.getItemModelResolver()
			.updateForTopItem(
				state.mainHandRenderState, state.mainHandItem, mainHandDisplayContext, player.level(), player, player.getId() + mainHandDisplayContext.ordinal()
			);
		player.minecraft
			.getItemModelResolver()
			.updateForTopItem(
				state.offHandRenderState, state.offHandItem, offHandDisplayContext, player.level(), player, player.getId() + offHandDisplayContext.ordinal()
			);
		state.mainHandUseDuration = state.mainHandItem.getUseDuration(player);
		state.offHandUseDuration = state.offHandItem.getUseDuration(player);
		state.mainHandChargeDuration = CrossbowItem.getChargeDuration(state.mainHandItem, player);
		state.offHandChargeDuration = CrossbowItem.getChargeDuration(state.offHandItem, player);
		state.mainHandSwapScale = player.minecraft.getItemModelResolver().swapAnimationScale(state.mainHandItem);
		state.offHandSwapScale = player.minecraft.getItemModelResolver().swapAnimationScale(state.offHandItem);
		state.hasMainHandMapData = this.extractMapRenderState(player, state.mainHandItem, state.mainHandMapRenderState);
		state.hasOffHandMapData = this.extractMapRenderState(player, state.offHandItem, state.offHandMapRenderState);
	}

	private boolean shouldInstantlyReplaceVisibleItem(final ItemStack currentlyVisibleItem, final ItemStack expectedItem, final LocalPlayer player) {
		return ItemStack.matchesIgnoringComponents(currentlyVisibleItem, expectedItem, DataComponentType::ignoreSwapAnimation)
			? true
			: !player.minecraft.getItemModelResolver().shouldPlaySwapAnimation(expectedItem);
	}

	private boolean extractMapRenderState(final LocalPlayer player, final ItemStack itemStack, final MapRenderState state) {
		MapId mapId = (MapId)itemStack.get(DataComponents.MAP_ID);
		MapItemSavedData mapData = mapId == null ? null : MapItem.getSavedData(mapId, player.level());
		if (mapId != null && mapData != null) {
			player.minecraft.getMapRenderer().extractRenderState(mapId, mapData, state);
			return true;
		} else {
			return false;
		}
	}

	public static FirstPersonHandsAndItemsRenderState.HandRenderSelection evaluateWhichHandsToRender(final LocalPlayer player) {
		ItemStack mainHandItem = player.getMainHandItem();
		ItemStack offhandItem = player.getOffhandItem();
		boolean holdsBow = mainHandItem.is(Items.BOW) || offhandItem.is(Items.BOW);
		boolean holdsCrossbow = mainHandItem.is(Items.CROSSBOW) || offhandItem.is(Items.CROSSBOW);
		if (!holdsBow && !holdsCrossbow) {
			return FirstPersonHandsAndItemsRenderState.HandRenderSelection.RENDER_BOTH_HANDS;
		} else if (!player.isUsingItem()) {
			return isChargedCrossbow(mainHandItem)
				? FirstPersonHandsAndItemsRenderState.HandRenderSelection.RENDER_MAIN_HAND_ONLY
				: FirstPersonHandsAndItemsRenderState.HandRenderSelection.RENDER_BOTH_HANDS;
		} else {
			ItemStack usedItemStack = player.getUseItem();
			InteractionHand usedHand = player.getUsedItemHand();
			if (!usedItemStack.is(Items.BOW) && !usedItemStack.is(Items.CROSSBOW)) {
				return usedHand == InteractionHand.MAIN_HAND && isChargedCrossbow(offhandItem)
					? FirstPersonHandsAndItemsRenderState.HandRenderSelection.RENDER_MAIN_HAND_ONLY
					: FirstPersonHandsAndItemsRenderState.HandRenderSelection.RENDER_BOTH_HANDS;
			} else {
				return FirstPersonHandsAndItemsRenderState.HandRenderSelection.onlyForHand(usedHand);
			}
		}
	}

	private static boolean isChargedCrossbow(final ItemStack item) {
		return item.is(Items.CROSSBOW) && CrossbowItem.isCharged(item);
	}
}
