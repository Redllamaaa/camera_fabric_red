package net.minecraft.world.level.storage.loot.providers.number.ints;

import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.core.Holder;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.Validatable;
import net.minecraft.world.level.storage.loot.ValidationContext;
import net.minecraft.world.level.storage.loot.providers.score.ScoreboardNameProvider;
import net.minecraft.world.level.storage.loot.providers.score.ScoreboardNameProviders;
import net.minecraft.world.scores.Objective;
import net.minecraft.world.scores.ReadOnlyScoreInfo;
import net.minecraft.world.scores.ScoreHolder;
import net.minecraft.world.scores.Scoreboard;
import org.jspecify.annotations.Nullable;

public record ScoreboardValue(ScoreboardNameProvider target, String score, Holder<ContextIntProvider> fallback) implements ContextIntProvider {
	public static final MapCodec<ScoreboardValue> MAP_CODEC = RecordCodecBuilder.mapCodec(
		i -> i.group(
				ScoreboardNameProviders.CODEC.fieldOf("target").forGetter(ScoreboardValue::target),
				Codec.STRING.fieldOf("score").forGetter(ScoreboardValue::score),
				ContextIntProviders.CODEC.optionalFieldOf("fallback", ContextIntProviders.exactly(0)).forGetter(ScoreboardValue::fallback)
			)
			.apply(i, ScoreboardValue::new)
	);

	@Override
	public MapCodec<ScoreboardValue> codec() {
		return MAP_CODEC;
	}

	@Override
	public void validate(final ValidationContext context) {
		Validatable.validate(context, "target", this.target);
		Validatable.validateHolder(context, "fallback", this.fallback);
	}

	private @Nullable ReadOnlyScoreInfo getScoreInfo(final LootContext context) {
		ScoreHolder scoreHolder = this.target.getScoreHolder(context);
		if (scoreHolder == null) {
			return null;
		}

		Scoreboard scoreboard = context.getLevel().getScoreboard();
		Objective objective = scoreboard.getObjective(this.score);
		return objective == null ? null : scoreboard.getPlayerScoreInfo(scoreHolder, objective);
	}

	@Override
	public int getIntUnsafe(final LootContext context) {
		ReadOnlyScoreInfo scoreInfo = this.getScoreInfo(context);
		return scoreInfo != null ? scoreInfo.value() : this.fallback.value().getIntUnsafe(context);
	}
}
